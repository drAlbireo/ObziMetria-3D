OBZIMETRIA 3D v2.2 - Windows (64-bit)
====================================

GETTING STARTED
1. Extract the ZIP archive if you downloaded the ZIP version.
2. Run ObziMetria_3D_v2.2_Windows.exe.
3. If Microsoft Edge is available, the application opens in an Edge app window.
   Otherwise, it opens in your default web browser.

WHAT IS INCLUDED?
The complete, unmodified contents of the original ObziMetria_3D_v2.2.html,
including the 3D model, star catalogs, settings, calculations, drawings,
simulation, and file-export features.

SYSTEM REQUIREMENTS
Windows 10 or 11 (64-bit); a modern web browser (Microsoft Edge recommended);
and WebGL-capable graphics hardware for the 3D view.
An internet connection is not required.

TECHNICAL INFORMATION
The Windows launcher extracts the original HTML file to this user folder:
%LOCALAPPDATA%\ObziMetria3D\ObziMetria_3D_v2.2.html
No installation or administrator permissions are required.
Plan and drawing exports use your browser's download settings.

IMPORTANT NOTES
This package does not contain its own browser engine. It uses Microsoft Edge
or another modern browser installed on your computer.
The EXE is not digitally signed, so Windows SmartScreen may display a warning
when downloading or launching it. Code signing is recommended before public
distribution.

Application credit: ObziMetria 3D by Mákszem Albert, version 2.2.

The Windows EXE was built in a Linux environment. It has not been possible to
perform a full launch and functionality test on an actual Windows computer here.
